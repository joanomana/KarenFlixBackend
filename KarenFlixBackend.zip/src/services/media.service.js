// Placeholder for future complex logic (e.g., ranking, approvals)
export const noop = () => {};